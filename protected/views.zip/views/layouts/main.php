<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
	 <meta name="keywords" content="<?php echo CHtml::encode($this->meta_keywords); ?>" />
	 <meta name="description" content="<?php echo CHtml::encode($this->meta_description); ?>" />	
	
	<meta name="viewport" content="initial-scale=1"/>
	<link rel="stylesheet" media="screen" href="/css/screen.css" >
        <link rel="stylesheet" href="/css/responsive.css" />
	<!--[if IE]><script src="/js/html5shiv.js"></script><![endif]-->

<!-- Hotjar Tracking Code for http://autotk.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1024206,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>
</head>
<body class="l">
<!-- BEGIN HEADER -->
<header>
	<a href="/" class="logo" title="Cars technical information"><span>Autotk</span>.com</a>
	<!--<div class="search">
		<input type="text" placeholder="Search">
		<button type="submit" class="btn btn_search"></button>
	</div>-->
	<!--
	<a href="#" class="sign-in">Sign in</a>
	<a href="#" class="join">Join</a>
	-->
</header>

<nav>
	<ul class="menu-list">
	<?php $uri = Yii::app()->request->requestUri;?>
		<li <?=($uri=='/')?'class="is-active"':''?>><a href="/">All cars</a></li>
<li><a href="https://amzn.to/2NWi7ba">Car Parts</a></li>
		<li <?=($uri=='/0-60-times.html')?'class="is-active"':''?>><a href="/0-60-times.html">0-60 times</a></li>
		<li <?=($uri=='/wheels.html')?'class="is-active"':''?>><a href="/wheels.html">Wheels</a></li>
		<li <?=($uri=='/tires.html')?'class="is-active"':''?>><a href="/tires.html">Tires</a></li>
		<li <?=($uri=='/horsepower.html')?'class="is-active"':''?>><a href="/horsepower.html">HP</a></li>
		<li <?=($uri=='/dimensions.html')?'class="is-active"':''?>><a href="/dimensions.html">Dimensions</a></li>
		<li <?=($uri=='/tuning.html')?'class="is-active"':''?>><a href="/tuning.html">Custom Cars</a></li>
	</ul>
</nav>

<ul class="breadcrumb">
	<?php foreach ($this->breadcrumbs as $url=>$item):?>
		<li>
			<?php 
			$anchor = '';
			$title = '';
			if (is_array($item)) {
				$anchor = $item['anchor'];
				if (isset($item['title']))
					$title = $item['title'];
			} else {
				$anchor = $item;
			}?>
		
			<?php if ($url != '#'):?>
				<a href="<?=$url?>" <?=!empty($title)?"title='{$title}'":""?> ><?=$anchor?></a><span>→</span>
			<?php else:?>
				<a href="#"><?=$anchor?></a>
			<?php endif;?>
		</li>
	<?php endforeach;?>
</ul>

<?php echo $content;?>

<!-- BEGIN FOOTER -->
<footer>
		<section class="footer__copyright"><br>
<p>autotk.com is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com.</p>

<br>		&copy <?=date('Y')?> Autotk.com. All Rights Reserved. <a rel="nofollow" href="/about.html">About us</a><br>
Found a mistake? We would be VERY grateful for flagging it here: <a href="mailto:autotkcom@gmail.com">autotkcom@gmail.com</a>
                </section>
</footer>

</body>
</html>

<?php if ($_SERVER['SERVER_NAME'] == 'autotk.com'):?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-2389032-35', 'auto');
  ga('send', 'pageview');

</script>
<?php endif;?>

<?php if (YII_DEBUG):?>
<div style="position:fixed;right:0;top:0;color:green;margin-right:5px;z-index:10000;">
  <?php $stat = Yii::app()->db->getStats();?>
  <?=$stat[0]?> / <?=round($stat[1],5)?>
</div> 
<?php endif;?>

<div id="amzn-assoc-ad-fe138798-62a2-4199-9958-a4e8eca2f9ee"></div><script async src="//z-na.amazon-adsystem.com/widgets/onejs?MarketPlace=US&adInstanceId=fe138798-62a2-4199-9958-a4e8eca2f9ee"></script>

<script async>(function(s,u,m,o,j,v){j=u.createElement(m);v=u.getElementsByTagName(m)[0];j.async=1;j.src=o;j.dataset.sumoSiteId='be9c1a4e3509614b10c4ecec8e66be8c2ac50cdd72c7ed84147e8c9e5a4e58f8';v.parentNode.insertBefore(j,v)})(window,document,'script','//load.sumo.com/');</script>


</body>
</html>
