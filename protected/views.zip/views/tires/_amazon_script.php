<?php if ($_SERVER['SERVER_NAME'] != 'auto.loc'):?>

<?php endif;?>