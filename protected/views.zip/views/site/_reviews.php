		<section class="years_box make">
		<?php foreach ($items as $text):?>
			<p><?=$text?></p>
		<?php endforeach;?>
		</section>