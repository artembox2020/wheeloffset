			<h2 class="section-name_2">Car specs and dimensions</h2>
                <table class="right-block__specs-list">
					<tbody>
						<tr>
							<td>
								<a title="car 0-60 times" class="speed" href="/0-60-times.html">0-60 times</a>
							</td>
						</tr>
						<tr>
							<td>
								<a title="Car horsepower" class="horsepower" href="/horsepower.html">Horsepower</a>
							</td>						
						</tr>						
						<tr>
							<td>
								<a title="Car dimensions" class="dim" href="/dimensions.html">Dimensions</a>
							</td>						
						</tr>
						<tr>
							<td>
								<a title="Car wheels and rims" class="rim" href="/wheels.html">Wheels</a>
							</td>						
						</tr>
						<tr>
							<td>
								<a class="tire" href="/tires.html">Tire size</a>
							</td>						
						</tr>
                        <tr>
							<td>
								<a class="tuning" href="/tuning.html">Custom Cars</a>
							</td>						
						</tr>
					</tbody>
                </table>
