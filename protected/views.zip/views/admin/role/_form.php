<?php echo $form->textFieldRow($model, 'title', array('class'=>'span6'))?>
