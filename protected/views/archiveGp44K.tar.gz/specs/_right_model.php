
<section class="right-block">
	<h2 class="section-name_2"><?=$make['title']?> <?=$model['title']?> specs</h2>
	
	<?php if (isset($lastModelYear['photo_270'])):?>

	<?php endif;?>
	

	
  
</section>				