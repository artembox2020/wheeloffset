	<h2 class="section-name_2"><?=$make['title']?> specs and dimensions</h2>
	
